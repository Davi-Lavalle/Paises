@extends('layouts.app')

@section('title','Filme')

@section('content')
<div id="geral">
<h1>Homem de ferro</h1>
<img src="https://img.elo7.com.br/product/zoom/267719C/big-poster-filme-iron-man-2008-lo02-tamanho-90x60-cm-iron-man.jpg" alt=""  id="cartaz">
</div>

@endsection