@extends('layouts.app')

@section('title','sinopse')

@section('content')
<div id="geral">
<h1>Sinopse</h1>
<p>Tony Stark é um industrial bilionário e inventor brilhante que realiza testes bélicos no exterior, mas é sequestrado por terroristas que o forçam a construir uma arma devastadora. Em vez disso, ele constrói uma armadura blindada e enfrenta seus sequestradores. Quando volta aos Estados Unidos, Stark aprimora a armadura e a utiliza para combater o crime.</p>
</div>
@endsection