

<?php $__env->startSection('title','sinopse'); ?>

<?php $__env->startSection('content'); ?>
<div id="geral">
<h1>Sinopse</h1>
<p>Tony Stark é um industrial bilionário e inventor brilhante que realiza testes bélicos no exterior, mas é sequestrado por terroristas que o forçam a construir uma arma devastadora. Em vez disso, ele constrói uma armadura blindada e enfrenta seus sequestradores. Quando volta aos Estados Unidos, Stark aprimora a armadura e a utiliza para combater o crime.</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\davil\Downloads\arquivos_20-06-24_14h51\Coteflix\resources\views/sinopse.blade.php ENDPATH**/ ?>