<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minha primeira aplicação laravel - <?php echo $__env->yieldContent('title'); ?></title>
    <style>
        nav{
            color: white;
            background-color:black;
            width: 100%;
            height: 40px;
            display: flex;
            align-items: center;
        }
        a{
            color:white;
            text-decoration:none;
            padding-left: 3%;
        }

        #geral{
            text-align: center;
        }
        .foto-elenco{
            width:150px;
            height: auto;
            padding-bottom: 2%;
        }

        .elenco{
            display: flex;
            justify-content: center;
        }

        .legenda{
            padding-left: 2%;
            display: flex;
            align-items: center;
        }
        
        #cartaz{
            width: 200px;
        }
        body{
            margin:0;
        }
    </style>
</head>
<body>
    <nav>
        <h4>Coteflix</h6>
        <a href="/">Principal</a>
        <a href="/sinopse">Sinopse</a>
        <a href="/elenco">Elenco</a>
    </nav>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH H:\www\Coteflix\resources\views/layouts/app.blade.php ENDPATH**/ ?>